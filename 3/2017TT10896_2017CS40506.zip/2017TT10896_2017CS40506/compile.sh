g++ pack.cpp -o pack
g++ unpack.cpp -o unpack
