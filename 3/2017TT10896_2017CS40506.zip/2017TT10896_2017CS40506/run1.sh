./pack $1
