./unpack $1
