g++ -std=c++11 a4.cpp -o a4
